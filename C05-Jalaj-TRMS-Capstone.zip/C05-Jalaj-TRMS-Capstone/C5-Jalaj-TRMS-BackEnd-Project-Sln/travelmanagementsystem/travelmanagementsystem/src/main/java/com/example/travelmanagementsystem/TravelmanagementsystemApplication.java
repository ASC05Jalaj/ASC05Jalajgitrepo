package com.example.travelmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelmanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelmanagementsystemApplication.class, args);
	}

}
