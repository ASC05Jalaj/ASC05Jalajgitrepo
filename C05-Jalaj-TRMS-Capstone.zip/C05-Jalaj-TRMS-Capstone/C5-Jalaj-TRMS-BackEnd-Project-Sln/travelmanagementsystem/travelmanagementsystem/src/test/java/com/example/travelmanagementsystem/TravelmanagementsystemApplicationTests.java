package com.example.travelmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
