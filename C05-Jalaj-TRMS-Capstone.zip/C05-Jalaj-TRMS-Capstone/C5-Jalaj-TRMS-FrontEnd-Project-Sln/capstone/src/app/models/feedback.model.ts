export interface Feedback {
    id?: string;
    rating: string;
    review: string;
    booking: {
      id: string;
    };
  }
  