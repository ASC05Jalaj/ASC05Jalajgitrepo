export interface TBook {
    id?: string;
    passenger: string;
    phoneNumber: string;
    pickup: string;
    destination: string;
    status: string;
    bookingDate: string;
    bookingTime: string;
    model: string;
    cabId: string;
  }
  