export interface Cabs {
    id: string; 
    model: string;
    vNumber: string;
    driver: string;
    seats: number;
  }
  